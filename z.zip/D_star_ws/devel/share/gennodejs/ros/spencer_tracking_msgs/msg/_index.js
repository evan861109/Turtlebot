
"use strict";

let ImmDebugInfo = require('./ImmDebugInfo.js');
let TrackedGroup = require('./TrackedGroup.js');
let DetectedPerson = require('./DetectedPerson.js');
let PersonTrajectory = require('./PersonTrajectory.js');
let DetectedPersons = require('./DetectedPersons.js');
let TrackedGroups = require('./TrackedGroups.js');
let TrackedPerson = require('./TrackedPerson.js');
let TrackedPersons2d = require('./TrackedPersons2d.js');
let TrackingTimingMetrics = require('./TrackingTimingMetrics.js');
let TrackedPerson2d = require('./TrackedPerson2d.js');
let TrackedPersons = require('./TrackedPersons.js');
let PersonTrajectoryEntry = require('./PersonTrajectoryEntry.js');
let ImmDebugInfos = require('./ImmDebugInfos.js');
let CompositeDetectedPersons = require('./CompositeDetectedPersons.js');
let CompositeDetectedPerson = require('./CompositeDetectedPerson.js');

module.exports = {
  ImmDebugInfo: ImmDebugInfo,
  TrackedGroup: TrackedGroup,
  DetectedPerson: DetectedPerson,
  PersonTrajectory: PersonTrajectory,
  DetectedPersons: DetectedPersons,
  TrackedGroups: TrackedGroups,
  TrackedPerson: TrackedPerson,
  TrackedPersons2d: TrackedPersons2d,
  TrackingTimingMetrics: TrackingTimingMetrics,
  TrackedPerson2d: TrackedPerson2d,
  TrackedPersons: TrackedPersons,
  PersonTrajectoryEntry: PersonTrajectoryEntry,
  ImmDebugInfos: ImmDebugInfos,
  CompositeDetectedPersons: CompositeDetectedPersons,
  CompositeDetectedPerson: CompositeDetectedPerson,
};
