
"use strict";

let GetPersonTrajectories = require('./GetPersonTrajectories.js')

module.exports = {
  GetPersonTrajectories: GetPersonTrajectories,
};
