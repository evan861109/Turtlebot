
"use strict";

let ScanAngle = require('./ScanAngle.js');

module.exports = {
  ScanAngle: ScanAngle,
};
