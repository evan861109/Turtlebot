
"use strict";

let TurtlebotMoveFeedback = require('./TurtlebotMoveFeedback.js');
let TurtlebotMoveActionFeedback = require('./TurtlebotMoveActionFeedback.js');
let TurtlebotMoveResult = require('./TurtlebotMoveResult.js');
let FindFiducialActionGoal = require('./FindFiducialActionGoal.js');
let TurtlebotMoveAction = require('./TurtlebotMoveAction.js');
let FindFiducialResult = require('./FindFiducialResult.js');
let FindFiducialFeedback = require('./FindFiducialFeedback.js');
let FindFiducialActionResult = require('./FindFiducialActionResult.js');
let TurtlebotMoveActionResult = require('./TurtlebotMoveActionResult.js');
let TurtlebotMoveGoal = require('./TurtlebotMoveGoal.js');
let TurtlebotMoveActionGoal = require('./TurtlebotMoveActionGoal.js');
let FindFiducialAction = require('./FindFiducialAction.js');
let FindFiducialGoal = require('./FindFiducialGoal.js');
let FindFiducialActionFeedback = require('./FindFiducialActionFeedback.js');

module.exports = {
  TurtlebotMoveFeedback: TurtlebotMoveFeedback,
  TurtlebotMoveActionFeedback: TurtlebotMoveActionFeedback,
  TurtlebotMoveResult: TurtlebotMoveResult,
  FindFiducialActionGoal: FindFiducialActionGoal,
  TurtlebotMoveAction: TurtlebotMoveAction,
  FindFiducialResult: FindFiducialResult,
  FindFiducialFeedback: FindFiducialFeedback,
  FindFiducialActionResult: FindFiducialActionResult,
  TurtlebotMoveActionResult: TurtlebotMoveActionResult,
  TurtlebotMoveGoal: TurtlebotMoveGoal,
  TurtlebotMoveActionGoal: TurtlebotMoveActionGoal,
  FindFiducialAction: FindFiducialAction,
  FindFiducialGoal: FindFiducialGoal,
  FindFiducialActionFeedback: FindFiducialActionFeedback,
};
