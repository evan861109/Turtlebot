#!/bin/bash
export ROS_MASTER_URI=http://192.168.0.100:11311  # Jackal's hostname and port
export ROS_HOSTNAME=MacbookPro.local # your computer's wireless IP address
