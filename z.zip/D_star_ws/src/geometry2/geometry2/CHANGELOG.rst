^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package geometry2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.20 (2018-11-16)
-------------------

0.5.19 (2018-11-06)
-------------------

0.5.18 (2018-07-10)
-------------------

0.5.17 (2018-01-01)
-------------------

0.5.16 (2017-07-14)
-------------------

0.5.15 (2017-01-24)
-------------------

0.5.14 (2017-01-16)
-------------------
* create geometry2 metapackage and make geometry_experimental depend on it for clarity of reverse dependency walking.
* Contributors: Tully Foote
