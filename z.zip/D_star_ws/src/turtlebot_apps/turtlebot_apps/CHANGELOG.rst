^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_apps
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.7 (2016-11-01)
------------------

2.3.6 (2016-06-29)
------------------

2.3.5 (2016-06-28)
------------------
* removing unnecessary dependencies
* Contributors: Tully Foote

2.3.4 (2016-06-28)
------------------
* disabling turtlebot_panorama due to it not compiling
* Contributors: Tully Foote

2.3.3 (2015-03-23)
------------------

2.3.2 (2015-01-21)
------------------

2.3.1 (2014-12-30)
------------------
* remove turtlebot_telop from meta package
* Contributors: Jihoon Lee

2.3.0 (2014-12-30)
------------------
* turtlebot_core_apps -> turtlebot_rapps, `#86 <https://github.com/turtlebot/turtlebot_apps/issues/86>`_
* Contributors: Daniel Stonier

2.2.4 (2013-10-14)
------------------

2.2.3 (2013-09-27)
------------------

2.2.2 (2013-09-26)
------------------

2.2.1 (2013-09-23)
------------------

2.2.0 (2013-08-30)
------------------
* Changelogs at package level.

2.1.x - hydro, unstable
=======================

2.1.1 (2013-08-09)
------------------
* Remove our beloved chirp app. Don't worry; it's now included on rocon_apps

2.1.0 (2013-07-19)
------------------
* Catkinized
* Needs to specify any individual panorama packages. Release complains if not


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_apps/ChangeList
