Original media files - these are used by the android apps and inserted in the bubble icons themselves.
