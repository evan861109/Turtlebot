struct RealPoint
{
  double x;
  double y;
  double theta;
};